package documentmanagement.domain;

import lombok.Data;

@Data
public class LoadPreviewQuery {

    private Long id;
}
