package documentmanagement.domain;

import lombok.Data;

@Data
public class LoadFilesQuery {

    private Long id;
}
