package documentmanagement.domain;

import lombok.Data;

@Data
public class SearchTextQuery {

    private String name;
}
